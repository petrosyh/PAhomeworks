(*
 * SNU 4541.664A Program Analysis 2017 Spring
 * K- Interpreter Solution
 * DongKwon Lee (dklee@ropas.snu.ac.kr)
 *)


(*
 * K- Interpreter
 *)

module type KMINUS =
sig
  exception Error of string
  type id = string
  type exp =
      | NUM of int
      | VAR of id
      | ADD of exp * exp
	  | MINUS of exp
	  | TRUE
	  | FALSE
	  | NOT of exp
	  | ANDALSO of exp * exp
	  | ORELSE of exp * exp
	  | LESS of exp * exp
  
  type cmd =
      | SKIP
      | SEQ of cmd * cmd        (* sequence *)
      | IF of exp * cmd * cmd   (* if-then-else *)
	  | WHILE of exp * cmd      (* while *)
      | ASSIGN of id * exp      (* assgin to variable *)

  type program = cmd
  type memory
  type value

  val botMemory : memory
  val eval : memory * exp -> value  (* exp eval *)
  val assume : memory * exp -> memory (* memory filtering *)
  val analyzer : memory * program -> memory
  val used_varlist : program -> id list
  val pp_memory : memory -> id list -> unit
end

module K : KMINUS =
struct
  exception Error of string
  type id = string
  type exp =
      | NUM of int
      | VAR of id
      | ADD of exp * exp
	  | MINUS of exp
	  | TRUE
	  | FALSE
	  | NOT of exp
	  | ANDALSO of exp * exp
	  | ORELSE of exp * exp
	  | LESS of exp * exp
  
  type cmd =
      | SKIP
      | SEQ of cmd * cmd        (* sequence *)
      | IF of exp * cmd * cmd   (* if-then-else *)
	  | WHILE of exp * cmd      (* while *)
      | ASSIGN of id * exp      (* assgin to variable *)



  type program = cmd
  
  (* abstract domain type : "do not" change here *)
  type bound = MIN | Z of int | MAX
  type itv = ITV of bound * bound | BOT_ITV
  type bool_hat = TOP_BOOL | T | F | BOT_BOOL
 
  (* abstract memory, value type : "do not" change here *)
  type value = itv * bool_hat
  type memory = id -> value
 
  (* bottom values *)
  let botValue = (BOT_ITV, BOT_BOOL)
  let botMemory = fun x -> botValue
  
  (* memory operation *)
  let store mem id v = fun x -> if (x = id) then v else mem(x)
  
  let rec compare_mem m1 m2 varlist =
    match varlist with
	| [] -> true
	| hd::tl -> (m1(hd) = m2(hd)) && (compare_mem m1 m2 tl)
 
  (* memory pretty print : "do not" change here *)
  let pp_bound : bound -> unit = fun bnd ->
    match bnd with
	| MIN -> print_string("MIN")
	| Z i -> print_int(i)
	| MAX -> print_string("MAX")

  let pp_itv : itv -> unit = fun itv ->
    match itv with
	| BOT_ITV -> print_string("bottom")
	| ITV (bnd1, bnd2) -> 
	  let _ = print_string("[") in
	  let _ = pp_bound(bnd1) in
	  let _ = print_string(", ") in
	  let _ = pp_bound(bnd2) in
	  print_string("]")
	  

  let pp_bool : bool_hat -> unit = fun b ->
    match b with
	| BOT_BOOL -> print_string("bottom") 
	| T -> print_string("T")
	| F -> print_string("F")
	| TOP_BOOL -> print_string("T, F")

  let rec pp_memory : memory -> id list -> unit = fun mem -> (fun varlist ->
    match varlist with
	| [] -> ()
	| hd::tl ->
	  let (itv, b) = mem(hd) in
	  let _ = print_string(hd ^ " -> interval : ") in
	  let _ = pp_itv(itv) in
	  let _ = print_string(" bool : ") in
	  let _ = pp_bool(b) in
	  let _ = print_newline() in
	  pp_memory mem tl
	  )
	 
  (* var list gathering : "do not" change here *)
  let rec list_trim l =
    match l with
	| [] -> []
	| hd::tl -> if (List.mem hd tl) then list_trim tl else hd::(list_trim tl)

  let rec used_vars_exp exp =
      (match exp with
      | NUM i -> []
      | VAR id -> id::[]
      | ADD (e1, e2) -> (used_vars_exp e1) @ (used_vars_exp e2)
	  | MINUS e -> used_vars_exp e
	  | TRUE -> []
	  | FALSE -> []
	  | NOT e -> used_vars_exp e
	  | ANDALSO (e1, e2) -> (used_vars_exp e1) @ (used_vars_exp e2)
	  | ORELSE (e1, e2) -> (used_vars_exp e1) @ (used_vars_exp e2)
	  | LESS (e1, e2) -> (used_vars_exp e1) @ (used_vars_exp e2)
	  )
  
  let rec used_vars cmd =
	match cmd with
	| SKIP -> []
	| SEQ (cmd1, cmd2) -> (used_vars cmd1) @ (used_vars cmd2)
	| IF (e, cmd1, cmd2) -> (used_vars_exp e) @ (used_vars cmd1) @ (used_vars cmd2)
	| WHILE (e, cmd) -> (used_vars_exp e) @ (used_vars cmd)
	| ASSIGN (id, e) -> id::(used_vars_exp e)

  let used_varlist cmd = list_trim (used_vars cmd)
 
  (* join operaters : you may need these operaters *)
  
  (* widening operaters : you may need these operaters *)
  
  (* narrowing operaters : you may need these operaters *)
 
  (* exp evaluation : TODO you have to implement this *)
  let rec eval : (memory * exp) -> value  = fun (mem, e) ->
    match e with
	| NUM i -> ((ITV (Z i, Z i)) , BOT_BOOL)
	| VAR x -> mem(x)
	| ADD (e1, e2) -> raise (Error ("not impled"))
    | _ -> raise (Error ("not impled"))
   
  (* memory filtering by boolean expression *)
  let rec assume : (memory * exp) -> memory = fun (mem, e) ->
    match e with
	| NUM i -> botMemory
	| VAR id -> raise (Error("not impled"))
	| _ -> raise (Error("not impled"))
   

  (* interval analysis for K- *)
  let rec analyzer : (memory * program) -> memory = fun (mem, pgm) ->
    let varlist = used_varlist pgm in
	match pgm with
	| SKIP -> mem
    | SEQ(cmd1, cmd2) -> let mem1 = analyzer (mem, cmd1) in analyzer (mem1, cmd2) 
    | IF(e, cmd1, cmd2) -> raise (Error("not impled"))
	| WHILE(e, cmd) -> raise (Error("not impled"))
	| ASSIGN(id, e) -> raise (Error("not impled"))
end
